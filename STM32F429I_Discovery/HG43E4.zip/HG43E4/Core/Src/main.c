#include "main.h"
#include "catimg.h"

LTDC_HandleTypeDef LtdcHandle; //lcd inicializáláshoz
static TS_StateTypeDef  TS_State; //ts inicializáláshoz
LTDC_LayerCfgTypeDef pLayerCfg; //layer inithez

__IO uint32_t Pending = 0;

gyro_t offset;

/* kép pozi */
uint32_t Xpos1 = 0;
uint32_t Ypos1 = 0;

/* ts méret */
uint16_t sizeX = 240;
uint16_t sizeY = 320;

int main(void)
{
  uint32_t i = 0;
  uint32_t jump_y = 10; //y tengelyen egységnyi ugrás nagysága
  uint32_t jump_delay = 200; //késleltetés az ugráshoz
  gyro_t gyroVal;

  HAL_Init();
  
  /* Configure the system clock to 180 MHz */
  SystemClock_Config();

  /* Btn */
  BSP_PB_Init(BUTTON_KEY, BUTTON_MODE_GPIO);

  /* LED3 */
  BSP_LED_Init(LED3);
  
  /*LCD*/
  LCD_Config();
  
  /* Line interrupthoz */
  HAL_LTDC_ProgramLineEvent(&LtdcHandle, 0);

  BSP_TS_Init(sizeX, sizeY);

  BSP_GYRO_Init();
  BSP_GYRO_Reset();
  Gyro_Calibration();

  /* Infinite loop */
  while (1)
  {
	  gyroVal = Gyro_GetXYZ();
	  if (gyroVal.omega_x > 50.0f) {
		BSP_LED_On(LED3);
	} else {
		BSP_LED_Off(LED3);
	}
	  if (!TS_IsTouchDetected() && BSP_PB_GetState(BUTTON_KEY) == RESET) {
	  	jump_y = 10;
	  	jump_delay = 200;
	  }
	  else {
	  	jump_y = 100;
	  	jump_delay = 100;
	  }

	  /* kép mozgatása felfelé */
	   for (i = 0; i < jump_y; i++)
	   {
	     PicturesPosition(&Xpos1, &Ypos1, i);
	     HAL_Delay(1);
	   }
	   HAL_Delay(jump_delay);

	   /* kép mozgatása lefelé */
	   for (i = jump_y; i > 0; i--)
	   {
	       PicturesPosition(&Xpos1, &Ypos1, i);
	       HAL_Delay(1);
	   }
	   HAL_Delay(jump_delay);
  }
}

/* kép pozíciójának változtatása */
static void PicturesPosition(uint32_t* x1, uint32_t* y1, uint32_t i)
{
  /* picture1 position */
  *x1 = 0;
  *y1 = 120-i;

  Pending = 1;
}

/* callback fv az lcd kijelzőn lévő újrarajzoláshoz */
void HAL_LTDC_LineEventCallback(LTDC_HandleTypeDef *hltdc)
{
  if (Pending == 1) {
	  /* 1es layer pozició újrakonfig */
	      HAL_LTDC_SetWindowPosition(&LtdcHandle, Xpos1, Ypos1, LTDC_LAYER_1);
	      Pending = 0;
  }
  /* line esemény rekonfig */
    HAL_LTDC_ProgramLineEvent(hltdc, 0);
}

static void LCD_Config(void)
{
  /* A ts-t működtető egység inicializálása*/
  ili9341_Init();

/* LTDC Initialization -------------------------------------------------------*/

  /* Polarity configuration */
  /* Initialize the horizontal synchronization polarity as active low */
  LtdcHandle.Init.HSPolarity = LTDC_HSPOLARITY_AL;
  /* Initialize the vertical synchronization polarity as active low */
  LtdcHandle.Init.VSPolarity = LTDC_VSPOLARITY_AL;
  /* Initialize the data enable polarity as active low */
  LtdcHandle.Init.DEPolarity = LTDC_DEPOLARITY_AL;
  /* Initialize the pixel clock polarity as input pixel clock */
  LtdcHandle.Init.PCPolarity = LTDC_PCPOLARITY_IPC;

  /* Timing configuration */
  /* Horizontal synchronization width = Hsync - 1 */
  LtdcHandle.Init.HorizontalSync = 9;
  /* Vertical synchronization height = Vsync - 1 */
  LtdcHandle.Init.VerticalSync = 1;
  /* Accumulated horizontal back porch = Hsync + HBP - 1 */
  LtdcHandle.Init.AccumulatedHBP = 29;
  /* Accumulated vertical back porch = Vsync + VBP - 1 */
  LtdcHandle.Init.AccumulatedVBP = 3;
  /* Accumulated active width = Hsync + HBP + Active Width - 1 */
  LtdcHandle.Init.AccumulatedActiveH = 323;
  /* Accumulated active height = Vsync + VBP + Active Heigh - 1 */
  LtdcHandle.Init.AccumulatedActiveW = 269;
  /* Total height = Vsync + VBP + Active Heigh + VFP - 1 */
  LtdcHandle.Init.TotalHeigh = 327;
  /* Total width = Hsync + HBP + Active Width + HFP - 1 */
  LtdcHandle.Init.TotalWidth = 279;

  /* Configure R,G,B component values for LCD background color */
  LtdcHandle.Init.Backcolor.Blue = 255;
  LtdcHandle.Init.Backcolor.Green = 255;
  LtdcHandle.Init.Backcolor.Red = 255;

  LtdcHandle.Instance = LTDC;

/* Layer1 Configuration ------------------------------------------------------*/

  /* Windowing configuration */
  pLayerCfg.WindowX0 = 0;
  pLayerCfg.WindowX1 = 205; //def: 205
  pLayerCfg.WindowY0 = 0;
  pLayerCfg.WindowY1 = 195; //def: 195

  /* Pixel Format configuration*/
  pLayerCfg.PixelFormat = LTDC_PIXEL_FORMAT_RGB565;

  /* Start Address configuration : frame buffer is located at FLASH memory */
  pLayerCfg.FBStartAdress = (uint32_t)&cat;

  /* Alpha constant (255 totally opaque) */
  pLayerCfg.Alpha = 255;

  /* Default Color configuration (configure A,R,G,B component values) */
  pLayerCfg.Alpha0 = 0;
  pLayerCfg.Backcolor.Blue = 255;
  pLayerCfg.Backcolor.Green = 255;
  pLayerCfg.Backcolor.Red = 255;

  /* Configure blending factors */
  pLayerCfg.BlendingFactor1 = LTDC_BLENDING_FACTOR1_PAxCA;
  pLayerCfg.BlendingFactor2 = LTDC_BLENDING_FACTOR2_PAxCA;

  /* Configure the number of lines and number of pixels per line */
  pLayerCfg.ImageWidth = 205; //default: 205
  pLayerCfg.ImageHeight = 195; //default: 195

  /* Configure the LTDC */
  if(HAL_LTDC_Init(&LtdcHandle) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  /* Configure the Background Layer*/
  if(HAL_LTDC_ConfigLayer(&LtdcHandle, &pLayerCfg, 0) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }
}

/* Van-e érintés a kijelzőn */
uint8_t TS_IsTouchDetected(void)
{
	BSP_TS_GetState(&TS_State);
	return (uint8_t)TS_State.TouchDetected;
}

void Gyro_Calibration(void)
{
	uint32_t duration = 1000;
	uint32_t time = HAL_GetTick();
	uint32_t n = 0;
	gyro_t sum;

	offset.omega_x = 0; offset.omega_y = 0; offset.omega_z = 0;
	sum = offset;
	while ((HAL_GetTick() - time) < duration)
	{
		sum.omega_x += Gyro_GetXYZ().omega_x;
		sum.omega_y += Gyro_GetXYZ().omega_y;
		sum.omega_z += Gyro_GetXYZ().omega_z;
		n++;
	}
	sum.omega_x /= n; sum.omega_y /= n; sum.omega_z /= n;

	offset = sum;
}

gyro_t Gyro_GetXYZ(void)
{
	gyro_union_t gyroVal;
	BSP_GYRO_GetXYZ(gyroVal.xyz);
	gyroVal.omega.omega_x -= offset.omega_x;
	gyroVal.omega.omega_y -= offset.omega_y;
	gyroVal.omega.omega_z -= offset.omega_z;
	return gyroVal.omega;
}

static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_PeriphCLKInitTypeDef  PeriphClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();
  
  /* The voltage scaling allows optimizing the power consumption when the device is 
     clocked below the maximum system frequency, to update the voltage scaling value 
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /*##-1- System Clock Configuration #########################################*/  
  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 360;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Activate the Over-Drive mode */
  HAL_PWREx_EnableOverDrive();
  
  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;  
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;  
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);

  /*##-2- LTDC Clock Configuration ###########################################*/  
  /* LCD clock configuration */
  /* PLLSAI_VCO Input = HSE_VALUE/PLL_M = 1 MHz */
  /* PLLSAI_VCO Output = PLLSAI_VCO Input * PLLSAIN = 192 MHz */
  /* PLLLCDCLK = PLLSAI_VCO Output/PLLSAIR = 192/4 = 48 MHz */
  /* LTDC clock frequency = PLLLCDCLK / RCC_PLLSAIDIVR_8 = 48/8 = 6 MHz */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LTDC;
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 192;
  PeriphClkInitStruct.PLLSAI.PLLSAIR = 4;
  PeriphClkInitStruct.PLLSAIDivR = RCC_PLLSAIDIVR_8;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct); 
}

static void Error_Handler(void)
{
  /* Turn LED3 on */
  BSP_LED_On(LED3);
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
