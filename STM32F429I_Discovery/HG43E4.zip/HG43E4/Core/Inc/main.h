#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f429i_discovery.h"
#include "stm32f429i_discovery_ts.h"
#include "ili9341.h"
#include "stmpe811.h"
#include "stm32f429i_discovery_gyroscope.h"

static void LCD_Config(void);
static void SystemClock_Config(void);
static void Error_Handler(void);
static uint8_t TS_IsTouchDetected(void);
static void Gyro_Calibration(void);
static gyro_t Gyro_GetXYZ(void);
static void PicturesPosition(uint32_t* x1, uint32_t* y1, uint32_t i);

#endif
